﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Relax Extractor")>
<Assembly: AssemblyDescription("Relax Automation Extractor")>
<Assembly: AssemblyCompany("FOXNET")>
<Assembly: AssemblyProduct("Relax")>
<Assembly: AssemblyCopyright("Copyright ©  2016 by Foxnet")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("82dadd43-fe16-4347-82e3-e43bbdfbb640")>

